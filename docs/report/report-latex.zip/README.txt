Bilingual report source. Open zh/report.tex or en/report.tex. Compile with XeLaTeX (English bibliography: BibTeX) or Tectonic. All section headings are left aligned.

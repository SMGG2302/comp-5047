Compile technical-zh.tex with XeLaTeX twice or Tectonic. Fonts: Arial and Microsoft YaHei. Original cover and automatic table-of-contents style retained; body rewritten into eight chapters.

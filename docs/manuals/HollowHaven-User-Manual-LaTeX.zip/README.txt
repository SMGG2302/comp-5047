Source: origin/main cfe177f, docs/manuals/HollowHaven-User-Manual-LaTeX.zip.
Edited directly from remote TeX; technical overlap removed from both languages.
Compile with XeLaTeX or Tectonic.

HollowHaven User Manual. Compile either .tex file with XeLaTeX twice or Tectonic. Required fonts: Arial and Microsoft YaHei. Keep screenshot PNGs beside the TeX files.
